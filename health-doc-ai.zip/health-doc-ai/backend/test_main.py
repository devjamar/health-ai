from fastapi.testclient import TestClient
from app.main import app
client=TestClient(app)
headers={'Authorization':'Bearer demo-token-change-me'}
def test_auth():
    assert client.get('/api/documents').status_code==401
def test_flow():
    r=client.post('/api/documents',headers=headers,files={'file':('sample.txt',b'Patient has elevated blood pressure. Follow-up appointment advised.','text/plain')})
    assert r.status_code==201
    id=r.json()['id']
    r=client.post(f'/api/documents/{id}/analyze',headers=headers)
    assert r.status_code==200
    assert len(r.json()['highlights'])>=2
    assert len(r.json()['recommendations'])>=1
    assert client.get('/api/documents?document_type=txt',headers=headers).json()['total']>=1
