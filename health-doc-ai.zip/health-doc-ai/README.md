# HealthDoc AI — document analysis MVP

FastAPI + React/TypeScript + SQLite. Mock analysis works without an API key. Use only synthetic/de-identified sample data; this is **not** a HIPAA-compliant clinical deployment.

## Backend

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
# Set a private token for non-local testing: APP_TOKEN=your-random-token
uvicorn app.main:app --reload --port 8000
```

API documentation: http://localhost:8000/docs

## Frontend

```bash
cd frontend
npm install
npm run dev
```

Open http://localhost:5173. Default demo token is `demo-token-change-me` (change this before any shared deployment). The token is stored in browser sessionStorage. Configure `VITE_API_URL` to override `http://localhost:8000`.

## REST API

All `/api/documents` endpoints require `Authorization: Bearer <APP_TOKEN>`.

- `POST /api/documents` multipart `file` (PDF/TXT) — uploads and extracts text.
- `POST /api/documents/{id}/analyze` — analyzes uploaded document.
- `GET /api/documents/{id}` — gets one result.
- `GET /api/documents?page=1&page_size=10&document_type=pdf&date_from=2026-01-01&date_to=2026-12-31` — filtered, paginated history.
- `GET /api/health` — liveness check.

## Live AI

Default `ANALYSIS_MODE=mock` provides deterministic placeholder findings and recommendations. To use OpenAI, set `ANALYSIS_MODE=openai`, `OPENAI_API_KEY=...`, optionally `OPENAI_MODEL=gpt-4o-mini`. Keys stay on the backend. Model-generated results must be clinically verified.

## Security limitations / production hardening

MVP uses one shared bearer token, not per-user authorization; a user can access all saved documents. Replace with user accounts, scoped authorization, token rotation, audit logging, HTTPS, rate limiting, and encryption at rest. SQLite contains extracted clinical text: use synthetic inputs only. Add retention/deletion policies, PHI controls, BAA/vendor assessment where applicable, PDF malware scanning, isolated PDF parsing, OCR for scanned PDFs, stricter JSON schema validation, and a human approval workflow before clinical use. Never log document bodies or AI requests. No file bytes are stored after extraction. The mock analyzer is keyword-based, not a clinically reliable anomaly detector.
